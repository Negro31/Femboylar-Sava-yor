const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

const MAX_PLAYERS = 2;
const COUNTDOWN_SECONDS = 10;

let players = {}; // { socketId: {id,name,color,x,y} }
let gameRunning = false;
let countdownTimer = null;
let countdownLeft = 0;
let winnerTimeout = null;

function broadcastLobbyStatus() {
  const playerCount = Object.keys(players).length;
  if (playerCount < MAX_PLAYERS && !gameRunning) {
    io.emit("lobbyStatus", { message: "Oyunun başlamasına son 1 kişi!" });
  } else {
    io.emit("lobbyStatus", { message: "" });
  }
}

function getSpawnPositions() {
  // Two spawn points on the platform
  return [
    { x: 250, y: 420 },
    { x: 550, y: 420 },
  ];
}

function startCountdownIfReady() {
  if (gameRunning) return;
  const ids = Object.keys(players);
  if (ids.length === MAX_PLAYERS && !countdownTimer) {
    countdownLeft = COUNTDOWN_SECONDS;
    io.emit("countdown", countdownLeft);
    countdownTimer = setInterval(() => {
      countdownLeft -= 1;
      if (countdownLeft > 0) {
        io.emit("countdown", countdownLeft);
      } else {
        clearInterval(countdownTimer);
        countdownTimer = null;
        gameRunning = true;
        io.emit("gameStart");
      }
    }, 1000);
  }
}

function stopCountdown() {
  if (countdownTimer) {
    clearInterval(countdownTimer);
    countdownTimer = null;
  }
  io.emit("countdown", null);
}

function resetGame() {
  stopCountdown();
  gameRunning = false;
  // Keep connected players but reset positions
  const spawns = getSpawnPositions();
  const ids = Object.keys(players);
  ids.forEach((id, idx) => {
    const spawn = spawns[idx % spawns.length];
    players[id].x = spawn.x;
    players[id].y = spawn.y;
  });
  io.emit("state", { players, gameRunning });
  broadcastLobbyStatus();
  startCountdownIfReady();
}

io.on("connection", (socket) => {
  socket.on("join", (name) => {
    const currentCount = Object.keys(players).length;
    if (currentCount >= MAX_PLAYERS && !players[socket.id]) {
      socket.emit("joinRejected", "Oda dolu (maksimum 2 oyuncu).");
      return;
    }
    if (!name || typeof name !== "string") name = "Oyuncu";
    const colors = ["#ff4d4f", "#4d79ff", "#34d399", "#fbbf24", "#a78bfa", "#f472b6"];
    const color = colors[Math.floor(Math.random() * colors.length)];
    // Assign spawn
    const spawns = getSpawnPositions();
    const index = Object.keys(players).length % spawns.length;
    const spawn = spawns[index];
    players[socket.id] = { id: socket.id, name, color, x: spawn.x, y: spawn.y };
    socket.emit("joined", players[socket.id]);
    io.emit("state", { players, gameRunning });
    broadcastLobbyStatus();
    startCountdownIfReady();
  });

  socket.on("declareWin", () => {
    if (!gameRunning) return;
    const p = players[socket.id];
    if (!p) return;
    io.emit("winner", p.name);
    if (winnerTimeout) clearTimeout(winnerTimeout);
    winnerTimeout = setTimeout(() => {
      resetGame();
    }, 5000);
  });

  socket.on("disconnect", () => {
    const existed = !!players[socket.id];
    const leavingName = existed ? players[socket.id].name : null;
    delete players[socket.id];
    io.emit("state", { players, gameRunning });
    if (gameRunning && existed && Object.keys(players).length === 1 && leavingName) {
      // Remaining player wins
      const remainingId = Object.keys(players)[0];
      const remainingName = remainingId ? players[remainingId].name : null;
      if (remainingName) {
        io.emit("winner", remainingName);
        if (winnerTimeout) clearTimeout(winnerTimeout);
        winnerTimeout = setTimeout(() => {
          resetGame();
        }, 5000);
      } else {
        resetGame();
      }
    } else {
      // If someone leaves during countdown or lobby, stop countdown and update status
      if (!gameRunning) {
        stopCountdown();
        broadcastLobbyStatus();
      }
    }
  });
});

server.listen(3000, () => {
  console.log("Server 3000 portunda çalışıyor");
});
