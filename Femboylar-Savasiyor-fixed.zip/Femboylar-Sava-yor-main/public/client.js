const socket = io();

const canvas = document.getElementById(\"gameCanvas\");
const ctx = canvas.getContext(\"2d\");

const loginDiv = document.getElementById(\"login\");
const nameInput = document.getElementById(\"nameInput\");
const startBtn = document.getElementById(\"startBtn\");

const lobbyStatusDiv = document.getElementById(\"lobbyStatus\");
const countdownDiv = document.getElementById(\"countdown\");
const playerListDiv = document.getElementById(\"playerList\");

let localPlayer = null;
let players = {};
let gameRunning = false;
let winnerOverlay = { text: null, until: 0 };

startBtn.onclick = () => {
  const name = nameInput.value.trim();
  if (!name) return;
  socket.emit(\"join\", name);
};

socket.on(\"joinRejected\", (msg) => {
  alert(msg);
});

socket.on(\"joined\", (me) => {
  localPlayer = me;
  loginDiv.style.display = \"none\";
});

socket.on(\"state\", (state) => {
  players = state.players || {};
  gameRunning = !!state.gameRunning;
  updatePlayerList(players);
});

socket.on(\"lobbyStatus\", ({ message }) => {
  lobbyStatusDiv.textContent = message || \"\";
});

socket.on(\"countdown\", (num) => {
  if (num === null || num === undefined) {
    countdownDiv.textContent = \"\";
  } else {
    countdownDiv.textContent = `Başlamasına: ${num}`;
  }
});

socket.on(\"gameStart\", () => {
  countdownDiv.textContent = \"Başladı!\";
  setTimeout(() => (countdownDiv.textContent = \"\"
  ), 1000);
});

socket.on(\"winner\", (name) => {
  winnerOverlay.text = String(name || \"KAZANAN\").toUpperCase();
  winnerOverlay.until = performance.now() + 5000;
});

function updatePlayerList(players) {
  playerListDiv.innerHTML = \"\";
  Object.values(players).forEach((p) => {
    const row = document.createElement(\"div\");
    row.textContent = `${p.name}`;
    row.style.color = p.color;
    playerListDiv.appendChild(row);
  });
}

// Simple demo controls: press SPACE after start to declare a win (for testing)
window.addEventListener(\"keydown\", (e) => {
  if (e.code === \"Space\" && gameRunning) {
    socket.emit(\"declareWin\");
  }
});

function drawPlatform() {
  // ground
  ctx.fillStyle = \"#333\";
  ctx.fillRect(0, 460, canvas.width, 40);
  // platform
  ctx.fillStyle = \"#555\";
  ctx.fillRect(150, 430, 500, 20);
}

function drawPlayers() {
  Object.values(players).forEach((p) => {
    // body
    ctx.fillStyle = p.color || \"white\";
    ctx.beginPath();
    ctx.arc(p.x, p.y, 15, 0, Math.PI * 2);
    ctx.fill();

    // name tag
    ctx.fillStyle = \"white\";
    ctx.font = \"12px Arial\";
    ctx.textAlign = \"center\";
    ctx.fillText(p.name, p.x, p.y - 22);
  });
}

function drawWinnerOverlay() {
  if (!winnerOverlay.text) return;
  const now = performance.now();
  if (now > winnerOverlay.until) {
    winnerOverlay.text = null;
    winnerOverlay.until = 0;
    return;
  }
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = \"black\";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.restore();

  ctx.fillStyle = \"white\";
  ctx.font = \"bold 48px Arial\";
  ctx.textAlign = \"center\";
  ctx.fillText(winnerOverlay.text, canvas.width / 2, canvas.height / 2);
}

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlatform();
  drawPlayers();
  drawWinnerOverlay();
  requestAnimationFrame(render);
}
render();
